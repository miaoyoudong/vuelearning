<template>
<div>
	<div id="example03">
		<el-row v-for="(value, time) in rect">
			<el-col :span="2" class="timeCol">{{time}}:</el-col>
			<el-col :span="2" v-for="col in value">
				<div  v-if="col>0" class="cell full"></div>
				<div  v-else class="cell empty"></div>
			</el-col>
		</el-row>
	</div>
	<div @dragstart.stop="handleDragStart" draggable="true">
		<el-row   v-for="(value, time) in rect" class="dragRow">
			<el-col :span="postSize*2" class="cell candidate"><div></div></el-col>
		</el-row>
	</div>
</div>
</template>

<script>
	export default {
		data() {
			return {
				rect:{
					"15:00":[0,1,0,0,0,0,0,0,1,0],
					"15:05":[0,1,0,0,0,0,0,0,1,0],
					"15:10":[0,1,0,0,1,0,0,0,1,0],
					"15:15":[0,1,0,0,0,0,0,0,1,0],
					"15:20":[0,1,0,0,0,1,0,0,1,0],
					"15:25":[0,1,0,0,0,0,0,0,1,0],
					"15:30":[0,1,0,0,1,0,0,0,1,0],
					"15:35":[0,1,0,0,0,0,0,0,1,0],
					"15:40":[0,1,0,0,0,0,0,0,1,0],
					"15:45":[0,1,0,0,0,0,0,0,1,0],
					"15:50":[0,1,0,1,0,0,0,0,1,0],
					"15:55":[0,1,0,0,0,0,0,0,1,0],
					"16:00":[0,1,0,0,0,0,0,0,1,0]
				},
				postSize:4
			}
		},
		methods: {
			handleDragStart(){
				 this.vm = this;
				 this.$el.style.backgroundColor = 'silver';
			}
		},
		watch:{
		      
		}
	}

</script>


<style scoped>
  .el-row {
  	margin-bottom: 0px;
  }

  .cell{
  	height:20px;
  }
  .full{
  	background: orange;
  }
  .empty{
  	background: grey;
  }
  .candidate{
  	background: blue;
  }
  .timeCol{
  	text-align: center;
  }
  .dragRow{
  	display: inline;
  }

</style>